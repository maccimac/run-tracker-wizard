package com.example.runtrackerwizardv11;

public interface Countdown {
    void onProgressUpdate(int i);
}
